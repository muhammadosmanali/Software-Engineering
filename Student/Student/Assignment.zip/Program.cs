﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student
{
    class Program
    {
        static void Main(string[] args)
        {
            Student obj = new Student();
            //Student obj2 = new Student("Usman", "2016CS107");
            obj.Input();
            System.Console.Clear();
            obj.Tostring();
        }
    }
}
